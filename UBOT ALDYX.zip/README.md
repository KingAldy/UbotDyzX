
```
apt update && apt upgrade -y
```
```
git clone https://github.com/bo
```
```
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
```
```
cd Ubotpremboy && screen -S mboy
```
```
bash installnode.sh && apt install python3.10-venv
```
```
python3 -m venv Uby && source Uboy/bin/activate
```
```
pip3 install -r requirements.txt
```
```
cp sample.env .env && nano .env
```
```
python3 -m PyroUbot
```
